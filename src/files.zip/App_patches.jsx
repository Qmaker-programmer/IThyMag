// ================================================================
//   iThyMag — PARCHES para App.jsx 🩹
//   1) Importar Comments al inicio de App.jsx
//   2) Reemplazar ProfileDropdown completo
//   3) Reemplazar DetailPanel completo
// ================================================================

// ══════════════════════════════════════════════════════════════
//  PASO 1: Agrega estas importaciones al inicio de App.jsx
//  (junto a los otros imports)
// ══════════════════════════════════════════════════════════════

import Comments from './Comments';
import './Comments.css';


// ══════════════════════════════════════════════════════════════
//  PASO 2: Reemplaza la función ProfileDropdown ENTERA
// ══════════════════════════════════════════════════════════════

function ProfileDropdown({ user, profile, onSave, onLogout, onClose }) {
  const [nickname, setNickname]       = useState(profile.nickname || '');
  const [hideName, setHideName]       = useState(profile.hideName || false);
  const [hidePhoto, setHidePhoto]     = useState(profile.hidePhoto || false);
  const [customPhoto, setCustomPhoto] = useState(profile.customPhotoUrl || '');
  const ref = useRef();
  useClickOutside(ref, onClose);

  const photo  = !hidePhoto ? (customPhoto || user.photoURL) : null;
  const letter = (nickname || user.displayName || '?')[0].toUpperCase();

  const handleSave = () => {
    if (hideName && !nickname.trim()) {
      alert('Si ocultas tu nombre real, necesitas un apodo 🎭');
      return;
    }
    onSave({ nickname, hideName, hidePhoto, customPhotoUrl: customPhoto });
  };

  return (
    <div ref={ref} className="profile-dropdown">
      <h3>Mi Perfil</h3>

      {/* Avatar preview */}
      {photo
        ? <img className="profile-avatar-big" src={photo} alt="" referrerPolicy="no-referrer" />
        : <div className="profile-avatar-placeholder">{letter}</div>}

      <input
        className="profile-input"
        placeholder="Apodo (opcional)"
        value={nickname}
        onChange={e => setNickname(e.target.value)}
      />
      <input
        className="profile-url-input"
        placeholder="URL de foto personalizada (opcional)"
        value={customPhoto}
        onChange={e => setCustomPhoto(e.target.value)}
      />

      {/* ── Toggle: Ocultar nombre ── */}
      <div
        className={`profile-toggle-row${hideName ? ' is-active' : ''}`}
        role="button"
        onClick={() => setHideName(v => !v)}
        style={{ cursor: 'pointer' }}
      >
        <div className="profile-toggle-label-wrap">
          <span className="profile-toggle-label">🙈 Ocultar nombre real</span>
          <span className="profile-toggle-sublabel">
            {hideName
              ? `Apareces como "${nickname || 'Anón'}" públicamente`
              : 'Tu nombre de Google se muestra públicamente'}
          </span>
        </div>
        {/* Badge de estado */}
        {hideName && <span className="profile-toggle-badge">ACTIVO</span>}
        <label
          className="toggle-switch"
          onClick={e => e.stopPropagation()}
        >
          <input
            type="checkbox"
            checked={hideName}
            onChange={e => setHideName(e.target.checked)}
          />
          <span className="toggle-slider" />
        </label>
      </div>

      {/* ── Toggle: Ocultar foto ── */}
      <div
        className={`profile-toggle-row${hidePhoto ? ' is-active' : ''}`}
        role="button"
        onClick={() => setHidePhoto(v => !v)}
        style={{ cursor: 'pointer' }}
      >
        <div className="profile-toggle-label-wrap">
          <span className="profile-toggle-label">📵 Ocultar foto de Google</span>
          <span className="profile-toggle-sublabel">
            {hidePhoto
              ? 'Usas la inicial de tu nombre como avatar'
              : 'Tu foto de Google se muestra en los posts'}
          </span>
        </div>
        {hidePhoto && <span className="profile-toggle-badge">ACTIVO</span>}
        <label
          className="toggle-switch"
          onClick={e => e.stopPropagation()}
        >
          <input
            type="checkbox"
            checked={hidePhoto}
            onChange={e => setHidePhoto(e.target.checked)}
          />
          <span className="toggle-slider" />
        </label>
      </div>

      <div className="profile-actions">
        <button className="btn-save-profile" onClick={handleSave}>Guardar</button>
        <button className="btn-logout" onClick={onLogout}>Salir</button>
      </div>
    </div>
  );
}


// ══════════════════════════════════════════════════════════════
//  PASO 3: Reemplaza la función DetailPanel ENTERA
// ══════════════════════════════════════════════════════════════

function DetailPanel({ art, open, onClose, onStar, onCopy, onShare, starred, currentUser, currentProfile, onEdit, onDelete, onLoginNeeded }) {
  const name    = art ? resolveAuthorName(art, currentUser, currentProfile) : '';
  const photo   = art ? resolveAuthorPhoto(art, currentUser, currentProfile) : null;
  const isOwner = currentUser && art && currentUser.uid === art.authorUid;

  return (
    <div className={`detail-panel-wrap${open ? ' open' : ''}`}>
      <div className="detail-panel">
        {art && <>
          <button className="panel-close" onClick={onClose}>✕</button>

          <div className="panel-author-row">
            <Avatar photo={photo} name={name} size={44} />
            <div>
              <div className="panel-author-name">@{name}</div>
              <div className="panel-date">{formatDate(art.createdAt)}</div>
            </div>
            {(art.stars || 0) > 0 && <span className="panel-stars">⭐ {art.stars}</span>}
          </div>

          <div className="panel-ascii-box">
            <pre>{art.content}</pre>
          </div>

          <div className="panel-tags">
            {art.tags?.filter(Boolean).map((t, i) => <span key={i} className="tag">#{t}</span>)}
          </div>

          <div className="panel-actions">
            <button className="btn-panel-copy" onClick={() => onCopy(art.content)}>Copiar ASCII</button>
            <button className="btn-panel-share" onClick={() => onShare(art)}>Compartir 🔗</button>
            <button className={`btn-panel-star${starred ? ' active' : ''}`} onClick={() => onStar(art)}>⭐</button>
          </div>

          {isOwner && (
            <div className="panel-owner-actions">
              <button className="btn-panel-edit" onClick={() => onEdit(art)}>✏️ Editar</button>
              <button className="btn-panel-delete" onClick={() => onDelete(art)}>🗑️ Borrar</button>
            </div>
          )}

          {/* ── COMENTARIOS EN ÁRBOL 🌳 ── */}
          <Comments
            artId={art.id}
            currentUser={currentUser}
            onLoginNeeded={onLoginNeeded}
          />
        </>}
      </div>
    </div>
  );
}


// ══════════════════════════════════════════════════════════════
//  PASO 4: En el JSX del componente App, donde usas <DetailPanel>,
//  agrega la prop onLoginNeeded:
// ══════════════════════════════════════════════════════════════

/*
  <DetailPanel
    art={selectedArt} open={panelOpen}
    onClose={closePanel} onStar={handleStar}
    onCopy={handleCopy} onShare={handleShare}
    starred={selectedArt ? starred.includes(selectedArt.id) : false}
    currentUser={user}
    currentProfile={profile}
    onEdit={handleEdit}
    onDelete={handleDelete}
    onLoginNeeded={() => setShowLogin(true)}   // <-- esta línea es nueva
  />
*/


// ══════════════════════════════════════════════════════════════
//  PASO 5 (opcional pero recomendado): Reglas de Firestore
//  Agrega esto en Firebase Console → Firestore → Rules
// ══════════════════════════════════════════════════════════════

/*
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Posts de arte
    match /artes/{artId} {
      allow read: if true;
      allow create: if request.auth != null;
      allow update, delete: if request.auth.uid == resource.data.authorUid;

      // Comentarios — subcolección anidada
      match /comments/{commentId} {
        allow read: if true;
        allow create: if request.auth != null;
        allow delete: if request.auth.uid == resource.data.authorUid;
      }
    }
  }
}
*/
