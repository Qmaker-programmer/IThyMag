// ================================================================
//   iThyMag — Comments.jsx 💬🌳
//   Comentarios en árbol con sub-replies y color-markdown
//   Guarda en Firestore: artes/{artId}/comments/{commentId}
// ================================================================
import { useState, useEffect, useRef, useCallback } from 'react';
import { db, auth } from './firebaseConfig';
import {
  collection, addDoc, query, orderBy,
  onSnapshot, serverTimestamp, doc, deleteDoc
} from 'firebase/firestore';

// ─────────────────────────────────────────────────────────────
//  COLOR MARKDOWN ENGINE
//  Sintaxis: [color]texto[/color]
//  Colores soportados:
//    rojo, verde, azul, amarillo, rosa, cyan, naranja, violeta,
//    blanco, gris, negro
//  También acepta hex: [#ff6b6b]texto[/#ff6b6b]
// ─────────────────────────────────────────────────────────────
const COLOR_MAP = {
  rojo:    '#ff6b6b',
  verde:   '#4ecdc4',
  azul:    '#38bdf8',
  amarillo:'#fbbf24',
  rosa:    '#f472b6',
  cyan:    '#22d3ee',
  naranja: '#fb923c',
  violeta: '#a78bfa',
  blanco:  '#f1f5f9',
  gris:    '#64748b',
  negro:   '#0f172a',
  // aliases inglés por si las moscas 🪲
  red:     '#ff6b6b',
  green:   '#4ecdc4',
  blue:    '#38bdf8',
  yellow:  '#fbbf24',
  pink:    '#f472b6',
  orange:  '#fb923c',
  purple:  '#a78bfa',
  white:   '#f1f5f9',
  gray:    '#64748b',
};

// Regex que captura [nombre_o_hex]contenido[/nombre_o_hex]
const COLOR_REGEX = /\[([a-zA-Z]+|#[0-9a-fA-F]{3,6})\]([\s\S]*?)\[\/\1\]/g;

export function parseColorMarkdown(text) {
  if (!text || !text.includes('[')) return [{ type: 'text', value: text }];

  const parts = [];
  let lastIndex = 0;
  let match;
  // Reset regex state
  COLOR_REGEX.lastIndex = 0;

  while ((match = COLOR_REGEX.exec(text)) !== null) {
    const [full, colorKey, content] = match;
    const start = match.index;

    // Texto antes del match
    if (start > lastIndex) {
      parts.push({ type: 'text', value: text.slice(lastIndex, start) });
    }

    // Resolver color
    const resolved = COLOR_MAP[colorKey.toLowerCase()] || (colorKey.startsWith('#') ? colorKey : null);
    if (resolved) {
      parts.push({ type: 'colored', color: resolved, value: content });
    } else {
      // Color no reconocido → mostrar tal cual
      parts.push({ type: 'text', value: full });
    }

    lastIndex = start + full.length;
  }

  // Resto de texto
  if (lastIndex < text.length) {
    parts.push({ type: 'text', value: text.slice(lastIndex) });
  }

  return parts.length ? parts : [{ type: 'text', value: text }];
}

// Renderiza texto con colores parseados
export function ColorText({ text, className = '' }) {
  const parts = parseColorMarkdown(text);
  return (
    <span className={className}>
      {parts.map((p, i) =>
        p.type === 'colored'
          ? <span key={i} style={{ color: p.color, fontWeight: 500 }}>{p.value}</span>
          : <span key={i}>{p.value}</span>
      )}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────
//  COLOR PICKER para el editor de comentarios
// ─────────────────────────────────────────────────────────────
const PALETTE = [
  { name: 'rojo',    color: '#ff6b6b' },
  { name: 'verde',   color: '#4ecdc4' },
  { name: 'azul',    color: '#38bdf8' },
  { name: 'amarillo',color: '#fbbf24' },
  { name: 'rosa',    color: '#f472b6' },
  { name: 'cyan',    color: '#22d3ee' },
  { name: 'naranja', color: '#fb923c' },
  { name: 'violeta', color: '#a78bfa' },
  { name: 'blanco',  color: '#f1f5f9' },
  { name: 'gris',    color: '#64748b' },
];

function ColorPicker({ onInsert }) {
  const [open, setOpen] = useState(false);
  const ref = useRef();

  useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  return (
    <div className="cm-picker-wrap" ref={ref}>
      <button
        type="button"
        className="cm-picker-btn"
        onClick={() => setOpen(v => !v)}
        title="Insertar color"
      >
        🎨
      </button>
      {open && (
        <div className="cm-palette">
          <div className="cm-palette-hint">Clic = insertar tag de color</div>
          <div className="cm-palette-grid">
            {PALETTE.map(({ name, color }) => (
              <button
                key={name}
                type="button"
                className="cm-swatch"
                style={{ background: color }}
                title={`[${name}]`}
                onClick={() => { onInsert(name); setOpen(false); }}
              />
            ))}
          </div>
          <div className="cm-palette-hint" style={{ marginTop: 6, opacity: 0.7 }}>
            O escribe: [rojo]texto[/rojo]
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  COMMENT FORM — el cuadro de texto para escribir
// ─────────────────────────────────────────────────────────────
function CommentForm({ onSubmit, placeholder = 'Escribe un comentario…', autoFocus = false, compact = false }) {
  const [text, setText] = useState('');
  const [preview, setPreview] = useState(false);
  const textareaRef = useRef();

  const insertColor = useCallback((colorName) => {
    const ta = textareaRef.current;
    if (!ta) return;
    const { selectionStart: s, selectionEnd: e } = ta;
    const selected = text.slice(s, e) || 'texto';
    const tag = `[${colorName}]${selected}[/${colorName}]`;
    const next = text.slice(0, s) + tag + text.slice(e);
    setText(next);
    // Re-posicionar cursor dentro del tag
    requestAnimationFrame(() => {
      ta.focus();
      const newPos = s + `[${colorName}]`.length + selected.length;
      ta.setSelectionRange(newPos, newPos + `[/${colorName}]`.length);
    });
  }, [text]);

  const handleSubmit = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    onSubmit(trimmed);
    setText('');
    setPreview(false);
  };

  const hasContent = text.trim().length > 0;
  const hasColors  = text.includes('[');

  return (
    <div className={`comment-form${compact ? ' comment-form-compact' : ''}`}>
      {/* Tabs preview/write */}
      {hasColors && (
        <div className="comment-form-tabs">
          <button type="button" className={`cm-tab${!preview ? ' active' : ''}`} onClick={() => setPreview(false)}>✏️ Escribir</button>
          <button type="button" className={`cm-tab${preview ? ' active' : ''}`} onClick={() => setPreview(true)}>👁️ Preview</button>
        </div>
      )}

      {preview ? (
        <div className="comment-preview">
          <ColorText text={text} />
        </div>
      ) : (
        <textarea
          ref={textareaRef}
          className="comment-textarea"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder={placeholder}
          rows={compact ? 2 : 3}
          autoFocus={autoFocus}
          onKeyDown={e => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) handleSubmit();
          }}
        />
      )}

      <div className="comment-form-actions">
        <ColorPicker onInsert={insertColor} />
        <span className="cm-hint">Ctrl+Enter para enviar</span>
        <button
          type="button"
          className="comment-submit-btn"
          onClick={handleSubmit}
          disabled={!hasContent}
        >
          Enviar 💬
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  SINGLE COMMENT — recursivo para el árbol 🌳
// ─────────────────────────────────────────────────────────────
function CommentNode({ comment, depth = 0, artId, currentUser, onDelete, allComments }) {
  const [showReply, setShowReply] = useState(false);
  const [collapsed, setCollapsed]   = useState(false);

  // Hijos directos de este comentario
  const children = allComments.filter(c => c.parentId === comment.id);

  const handleReply = async (text) => {
    if (!currentUser) return;
    await addDoc(collection(db, 'artes', artId, 'comments'), {
      text,
      parentId: comment.id,
      authorUid:      currentUser.uid,
      authorName:     currentUser.displayName || 'Anón',
      authorPhoto:    currentUser.photoURL || '',
      createdAt:      serverTimestamp(),
    });
    setShowReply(false);
  };

  const isOwner = currentUser && currentUser.uid === comment.authorUid;
  const indent  = Math.min(depth, 4); // máximo 4 niveles de indentación visual

  return (
    <div className={`comment-node depth-${indent}`} style={{ '--depth': indent }}>
      <div className="comment-bubble">
        {/* Avatar + meta */}
        <div className="comment-meta">
          <div className="comment-avatar">
            {comment.authorPhoto
              ? <img src={comment.authorPhoto} alt="" referrerPolicy="no-referrer" />
              : (comment.authorName || '?')[0].toUpperCase()
            }
          </div>
          <div className="comment-meta-info">
            <span className="comment-author">{comment.authorName || 'Anón'}</span>
            <span className="comment-date">{formatRelative(comment.createdAt)}</span>
          </div>
          <div className="comment-meta-actions">
            {children.length > 0 && (
              <button
                className="comment-collapse-btn"
                onClick={() => setCollapsed(v => !v)}
                title={collapsed ? 'Expandir' : 'Colapsar'}
              >
                {collapsed ? `▶ ${children.length}` : '▼'}
              </button>
            )}
            {isOwner && (
              <button
                className="comment-delete-btn"
                onClick={() => onDelete(comment)}
                title="Borrar"
              >
                🗑️
              </button>
            )}
          </div>
        </div>

        {/* Texto con colores */}
        <div className="comment-text">
          <ColorText text={comment.text} />
        </div>

        {/* Acción de responder */}
        {currentUser && (
          <button
            className="comment-reply-btn"
            onClick={() => setShowReply(v => !v)}
          >
            {showReply ? '✕ Cancelar' : '↩ Responder'}
          </button>
        )}

        {showReply && (
          <div className="comment-reply-form">
            <CommentForm
              onSubmit={handleReply}
              placeholder={`Responder a ${comment.authorName}…`}
              autoFocus
              compact
            />
          </div>
        )}
      </div>

      {/* Hijos recursivos */}
      {!collapsed && children.length > 0 && (
        <div className="comment-children">
          {children.map(child => (
            <CommentNode
              key={child.id}
              comment={child}
              depth={depth + 1}
              artId={artId}
              currentUser={currentUser}
              onDelete={onDelete}
              allComments={allComments}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  FECHA RELATIVA
// ─────────────────────────────────────────────────────────────
function formatRelative(ts) {
  if (!ts) return '';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  const diff = Date.now() - d.getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)   return 'ahora';
  if (mins < 60)  return `hace ${mins}m`;
  if (hours < 24) return `hace ${hours}h`;
  if (days < 7)   return `hace ${days}d`;
  return d.toLocaleDateString('es', { day: 'numeric', month: 'short' });
}

// ─────────────────────────────────────────────────────────────
//  COMMENTS PANEL — componente principal exportado
// ─────────────────────────────────────────────────────────────
export default function Comments({ artId, currentUser, onLoginNeeded }) {
  const [comments, setComments]         = useState([]);
  const [loading, setLoading]           = useState(true);
  const [deleteTarget, setDeleteTarget] = useState(null);

  // Cargar comentarios en tiempo real
  useEffect(() => {
    if (!artId) return;
    setLoading(true);
    const q = query(
      collection(db, 'artes', artId, 'comments'),
      orderBy('createdAt', 'asc')
    );
    const unsub = onSnapshot(q, snap => {
      setComments(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return unsub;
  }, [artId]);

  const handlePost = async (text) => {
    if (!currentUser) { onLoginNeeded?.(); return; }
    await addDoc(collection(db, 'artes', artId, 'comments'), {
      text,
      parentId:    null, // comentario raíz
      authorUid:   currentUser.uid,
      authorName:  currentUser.displayName || 'Anón',
      authorPhoto: currentUser.photoURL || '',
      createdAt:   serverTimestamp(),
    });
  };

  const handleDelete = async (comment) => {
    setDeleteTarget(comment);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    await deleteDoc(doc(db, 'artes', artId, 'comments', deleteTarget.id));
    setDeleteTarget(null);
  };

  // Solo comentarios raíz
  const roots = comments.filter(c => !c.parentId);

  return (
    <div className="comments-section">
      <div className="comments-header">
        <span className="comments-title">💬 Comentarios</span>
        <span className="comments-count">{comments.length}</span>
      </div>

      {/* Caja de color-markdown guide */}
      <details className="cm-guide">
        <summary>🎨 ¿Cómo usar colores?</summary>
        <div className="cm-guide-body">
          <p>Usa tags para colorear tu texto:</p>
          <div className="cm-guide-examples">
            {[
              { tag: 'rojo', label: 'rojo' },
              { tag: 'verde', label: 'verde' },
              { tag: 'azul', label: 'azul' },
              { tag: 'amarillo', label: 'amarillo' },
              { tag: 'rosa', label: 'rosa' },
              { tag: 'violeta', label: 'violeta' },
              { tag: 'naranja', label: 'naranja' },
              { tag: 'cyan', label: 'cyan' },
            ].map(({ tag, label }) => (
              <code key={tag} style={{ color: COLOR_MAP[tag] }}>
                [{label}]texto[/{label}]
              </code>
            ))}
          </div>
          <p style={{ marginTop: 8, opacity: 0.7, fontSize: '0.75rem' }}>
            O usa el botón 🎨 para insertar automáticamente
          </p>
        </div>
      </details>

      {/* Form de comentario raíz */}
      {currentUser ? (
        <CommentForm onSubmit={handlePost} placeholder="Deja un comentario… 💬" />
      ) : (
        <button className="comments-login-cta" onClick={onLoginNeeded}>
          Inicia sesión para comentar 💬
        </button>
      )}

      {/* Lista de comentarios */}
      {loading ? (
        <div className="comments-loading">Cargando comentarios…</div>
      ) : roots.length === 0 ? (
        <div className="comments-empty">Sé el primero en comentar 👀</div>
      ) : (
        <div className="comments-list">
          {roots.map(c => (
            <CommentNode
              key={c.id}
              comment={c}
              depth={0}
              artId={artId}
              currentUser={currentUser}
              onDelete={handleDelete}
              allComments={comments}
            />
          ))}
        </div>
      )}

      {/* Confirm delete dialog */}
      {deleteTarget && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setDeleteTarget(null)}>
          <div className="modal" style={{ width: 300, textAlign: 'center', gap: 14, display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '2rem' }}>🗑️</div>
            <p style={{ fontSize: '0.88rem' }}>¿Borrar este comentario?</p>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn-logout" onClick={confirmDelete} style={{ flex: 1 }}>Sí, borrar</button>
              <button className="btn-save-profile" onClick={() => setDeleteTarget(null)} style={{ flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
